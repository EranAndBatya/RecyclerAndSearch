package com.example.recyclerexample;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


import androidx.appcompat.widget.Toolbar;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {

    private Toolbar toolbar;
    private RecyclerView m_recycleView;
    private RecyclerView.LayoutManager m_LayoutManager;
    private List<String> m_list = new ArrayList<>();
    private RecyclerAdapter m_adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        m_recycleView=findViewById(R.id.recyclerView);
        m_LayoutManager=new LinearLayoutManager(this);
        m_recycleView.setLayoutManager(m_LayoutManager);
        m_recycleView.setHasFixedSize(true);

        m_list= Arrays.asList(getResources().getStringArray(R.array.android_versions));
        m_adapter= new RecyclerAdapter(m_list);
        m_recycleView.setAdapter(m_adapter);

    }

    //--------------for search----------------------------------------------
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.toolbar_menu,menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String query)
    {

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText)
    {
        String userInput = newText.toLowerCase();
        List<String> newList = new ArrayList<>();

        for(String name : m_list)
        {
            if(name.toLowerCase().contains(userInput))
            {
                newList.add(name);
            }
        }
        m_adapter.updateList(newList);
       return true;
    }
}
