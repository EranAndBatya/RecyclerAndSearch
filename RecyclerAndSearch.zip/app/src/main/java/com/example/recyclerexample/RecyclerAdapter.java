package com.example.recyclerexample;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>
{
    private List<String> m_list;

    public RecyclerAdapter(List<String>list){
        m_list=list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        TextView textView= (TextView)LayoutInflater.from(parent.getContext()).inflate(R.layout.text_view_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(textView);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder( MyViewHolder holder, int position)
    {
        holder.m_Versionname.setText(m_list.get(position));

    }

    @Override
    public int getItemCount() {
        return m_list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder
    {

        TextView m_Versionname;
        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);
            m_Versionname = (TextView) itemView;
        }
    }
    //------------------for search-------------------
    public  void updateList(List<String> newList)
    {
        m_list = new ArrayList<>();
        m_list.addAll(newList);
        notifyDataSetChanged();

    }
}
